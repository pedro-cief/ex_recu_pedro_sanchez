#!/bin/bash


# Crear las carpetas y el archivo oculto
mkdir glass1 glass2 glass3

# Generar una carpeta aleatoria para esconder el archivo llamado marble
random_glass=$(( RANDOM % 3 + 1 ))
marble_path="glass${random_glass}/marble"
echo "I am Marble" > $marble_path
chmod 444 $marble_path

# Variables para contar los intentos
attempts=0
found=0

# Preguntar por el nombre del jugador
read -p "Enter your name: " player_name

# Juego principal
while [ $found -eq 0 ]; do
    read -p "Guess the folder where the marble is hidden (1, 2, 3): " guess
    attempts=$(( attempts + 1 ))

    if [ "$guess" -eq "$random_glass" ]; then
        echo "Congratulations! You found the marble."
        found=1
    else
        echo "Wrong guess. Try again."
    fi
done

# Guardar el resultado en summary.txt
echo "$player_name found the marble in $attempts attempts" >> summary.txt

# Establecer permisos para summary.txt
chmod 644 summary.txt

# Preguntar si se desea borrar el juego
read -p "Do you want to delete the game files? (y/n): " delete_choice

if [[ "$delete_choice" == "y" || "$delete_choice" == "Y" ]]; then
    rm -rv glass1 glass2 glass3
fi

# Mostrar el contenido de summary.txt
cat summary.txt

# Establecer permisos para summary.txt (de nuevo por seguridad)
chmod 644 summary.txt
